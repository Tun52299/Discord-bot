// module.exports = {
//   name: 'debug',
//   type: 'voiceExtractor',
//   execute: async debug => {
//     console.log(debug);
//   },
// };
